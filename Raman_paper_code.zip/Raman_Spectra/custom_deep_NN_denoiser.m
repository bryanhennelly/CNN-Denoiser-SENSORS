%deep raman denoiser training using the customized loss function


numFeatures=600; %number of samples

% define the network layers
layers = [imageInputLayer([numFeatures,1,1],"Normalization","zerocenter","mean",mean(targets,'all'),"name","input")
          convolution2dLayer([9 1],256,"Stride",1,"Padding","same","name","conv_1")
          batchNormalizationLayer("name","bnorm_1")
          reluLayer("name","relu_1")
          
          convolution2dLayer([5 1],128,"Stride",1,"Padding","same","name","conv_2")
          batchNormalizationLayer("name","bnorm_2")
          reluLayer("name","relu_2")
          
          convolution2dLayer([5 1],64,"Stride",1,"Padding","same","name","conv_3")
          batchNormalizationLayer("name","bnorm_3")
          reluLayer("name","relu_3")
          
          
          convolution2dLayer([9 1],1,"Stride",1,"Padding","same","name","conv_4")
          batchNormalizationLayer("name","bnorm_4")
          reluLayer("name","relu_4")
          
          convolution2dLayer([numFeatures 1],1,"Stride",1,"Padding","same","name","conv_5")
          ];
%store the model in the GPU
lgraph=layerGraph(layers);
dlnet = dlnetwork(lgraph);

%training settings
miniBatchSize = 128; 
learnRate=1e-9;
learnateDropFactor=0.5;   
learnRateDropPeriod=50;    
trailingAvg=[];   
trailingAvgS=[];
velocity=[];   
numEpochs=100;   
gradientDecayFactor = 0.5;   
squaredGradientDecayFactor = 0.999;   
iteration=1;   
executionEnvironment = "gpu";   
plots = "training-progress";  
if plots == "training-progress"
        figure
        lineLossTrain = animatedline;
        xlabel("Total Iterations")
        ylabel("Loss")
end

momentum=0.9;

%find dominant peeks for each training signal for our customized loss
%function
[pkRange]=peakDefiner(targets);


%Enter training loop
for epoch = 1:numEpochs
     r=randperm(size(predictors,4));
     predictors_shuff=predictors(:,:,:,r);
     targets_shuff=targets(:,:,:,r);
     pkRange_shuff=pkRange(r,:);
     if mod(epoch,learnRateDropPeriod)==0
         learnRate=learnRate*learnateDropFactor;
     end
     %for each mini-batch
     for i=1:miniBatchSize:size(predictors,4)
        
        X=predictors_shuff(:,:,:,i:min(end,(i+miniBatchSize-1)));
        T=targets_shuff(:,:,:,i:min(end,(i+miniBatchSize-1)));
        pks=pkRange_shuff(i:min(end,(i+miniBatchSize-1)),:);
        dlX = dlarray(X, 'SSCB');
        dlT = dlarray(T, 'SSCB');
        
        % If training on a GPU, then convert data to gpuArray.
        if (executionEnvironment == "auto" && canUseGPU) || executionEnvironment == "gpu"
            dlX = gpuArray(dlX);
            dlT = gpuArray(dlT);
        end
        
        % Evaluate the model gradients 
        [gradients, loss,state] = ...
            dlfeval(@modelGradients, dlnet, dlX, dlT,pks);
        dlnet.State = state;
        % Update the parameters.
        [dlnet, velocity] = sgdmupdate(dlnet, gradients, velocity, learnRate, momentum);
        
        
        if plots == "training-progress"
            addpoints(lineLossTrain,iteration,double(gather(extractdata(loss))))
            title("Loss During Training: Epoch - " + epoch + "; Iteration - " + iteration)
            drawnow
        end
        iteration=iteration+1;
    end
end



function [gradient, loss,state] = ...
    modelGradients(dlnet, dlX, dlT,pkRange)
    
    [dlYPred,state] = forward(dlnet, dlX);
    loss =snrLoss(dlYPred,dlT,dlX,pkRange);
    
    gradient = dlgradient(loss, dlnet.Learnables);

end


