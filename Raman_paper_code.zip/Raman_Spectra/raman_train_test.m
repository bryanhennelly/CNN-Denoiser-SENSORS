%generate training data
clear; 
num_spectra =10000; 
generateSpectra
[predictors,targets] = shotNoise(Raman_spectrum');

%generate and train the model
custom_deep_NN_denoiser



%denoise test samples
clear data; 
data=dlmread(['rawData.txt'],','); 
m=max(data,[],'all');
%testing samples are scaled in order to be consistent with the magnitue of
%the training data
sacaling_factor=5000/m;
data=data'*sacaling_factor; 
noisy_test_samples=reshape(data,[600 1 1 750]);
denoised=predict(dlnet,gpuArray(dlarray(noisy_test_samples,'SSCB'))); 
denoised_raw_data=gather(extractdata(denoised))/scaling_factor;
