% predictors noise is a function of the spectral intensity
function [predictors,targets] = shotNoise(spec)

    predictors = zeros(size(spec,1),1,1,size(spec,2));
    targets=zeros(size(spec,1),1,1,size(spec,2));
    for j=1:size(spec,2)
        j
            for i = 1 : 1 : size(spec,1)
                predictors(i,1,1,j) = poissrnd(spec(i,j));  
                targets(i,1,1,j)=spec(i,j);
            end
    end
end