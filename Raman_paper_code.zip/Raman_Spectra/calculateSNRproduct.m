% SNR Product: The higher the SNR product, the better
% The function takes in denoised data and the gnerated data (before the noise is added)
% The data is assumed to be a 1xn vector in both cases
% The variable peak region is a 1x3 vector indicating the samples
% containing the peak of interest, sharp/narrow peaks are the most
% useful
% This is designed to use information from the peakDefiner function

function[snrProduct] = calculateSNRproduct(denoisedData, generatedData, noisyData, pkRegion)

% remainsNoised = noisyData-generatedData;
% remainsDenoised = denoisedData-generatedData;
% 
% snrDenoised = max(generatedData)/std(remainsDenoised);
% snrNoised = max(generatedData)/std(remainsNoised);
% snrDenoisedPeak = max(generatedData)/std(remainsDenoised(pkRegion(2):pkRegion(3)));
% snrNoisedPeak = max(generatedData)/std(remainsNoised(pkRegion(2):pkRegion(3)));
% % Bryan recommended adding them/weighting them in some way. Would suggest
% % leaving it as is for the moment. If it's not working well, let me know
% % and I'll optimise a weight for it on an experimental dataset.
%size(generatedData)
%snrProduct = (snrDenoised(1,1,1,1)./snrNoised(1,1,1,1)).*(snrDenoisedPeak(1,1,1,1)./snrNoisedPeak(1,1,1,1));
%denoisedData(pkRegion(2):pkRegion(3),1,1)
%pkRegion
denoisedData_pkrgn=dlarray(denoisedData(pkRegion(2):pkRegion(3),1,1), 'SSCB');
generatedData_pkrgn=dlarray(generatedData(pkRegion(2):pkRegion(3),1,1), 'SSCB');
snrProduct=mse(denoisedData,generatedData)+50*mse(denoisedData_pkrgn,generatedData_pkrgn);
end


