function loss = snrLoss(denoised, original_test_samples, noisy_test_samples, pkRange)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
    for i=1:size(denoised,4) 
        snrProduct(i) = calculateSNRproduct(denoised(:,:,:,i), original_test_samples(:,:,:,i), noisy_test_samples(:,:,:,i), pkRange(i,:)); 
    end
    loss=mean(snrProduct);
end
%mse+mse_of_the_peek
%sgolayfilt