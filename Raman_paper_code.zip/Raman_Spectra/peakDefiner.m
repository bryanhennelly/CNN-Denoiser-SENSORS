function [pkRange] = peakDefiner(original_test_samples)

generatedMat = squeeze(original_test_samples);

dim = size(generatedMat);

pkRange = zeros(dim(2),3);

for i = 1 : 1 : dim(2)
    [pks, locs, w, p] = findpeaks(generatedMat(:,i));

%     Find the most prominent peak
    [promPk, promLoc] = max(p);
    
%     Find local minima of the spectra
    [minimaLocs] = islocalmin(generatedMat(:,i));
    
% Find closest local minima to the most prominent peak    
    stopCounter = locs(promLoc);
    startCounter = stopCounter;

%   Error checking to ensure that there is a local minima to find
    if sum(minimaLocs(stopCounter:end))>0 
        while minimaLocs(stopCounter) == 0
            stopCounter = stopCounter + 1;
        end
    else
%         If there isn't a local minima add half the peak width to the
%         centre point
        stopCounter = stopCounter + (round(w(promLoc)/2));
    end
    
    if sum(minimaLocs(1:startCounter))>0
        while minimaLocs(startCounter) == 0
            startCounter = startCounter - 1;
        end
    else
        startCounter = startCounter - (round(w(promLoc)/2));
    end
    startCounter=max(startCounter,1);
    stopCounter=min(stopCounter,dim(1));
%     Store the defined peak area in the form:
%     [centrePoint, startPoint, stopPoint]
    pkRange(i,:) = [locs(promLoc), startCounter, stopCounter]; 
     
%     figure(1), clf, hold
%     plot(generatedMat(:,i))
%     plot(pkRange(i,2), generatedMat(pkRange(i,2),i), 'r*')
%     plot(pkRange(i,3), generatedMat(pkRange(i,3),i), 'r*'), pause
%     
end

end


