% Preallocations

band   =  0.1:1:600;
 

clear Xi_res  Raman_spectrum;

% Make the spectral datasetDD



Xi_res = zeros(num_spectra,600);

for m = 1:num_spectra

    for n = 1:randi([10,100],1)%n_peaks

        %------------------------------------------------------------------------%

        %Lorentzian function  

        frq    =  randi([2,598],1); % resonant frequency

        FWHM   =  randi([5,300],1);    % bandwidth (FWHM)

        amp     =  10000*rand;     % oscillator strength

        res   =  (  ( amp * frq )./ (frq*frq-band.*band-1i.*band*FWHM)); % Cauchy
        

        %------------------------------------------------------------------------%

        Xi_res(m,:) = Xi_res(m,:) + res;

    end

    Raman_spectrum(m,:) = imag(Xi_res(m,:));


end

figure;plot(Raman_spectrum')